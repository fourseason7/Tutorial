﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraBars;
using DevExpress.LookAndFeel;

namespace InotechWireless
{
    public partial class frmMainRibbon : DevExpress.XtraBars.Ribbon.RibbonForm
    {
        public frmMainRibbon()
        {
            InitSkins();
            InitializeComponent();
        }

        public void InitSkins()
        {
            DevExpress.Skins.SkinManager.EnableFormSkins();
            DevExpress.UserSkins.BonusSkins.Register();
            UserLookAndFeel.Default.SetSkinStyle(Properties.Settings.Default.LaskSkin);
        }
        private void InitSkinGallery()
        {
            DevExpress.XtraBars.Helpers.SkinHelper.InitSkinGallery(rgbSkins, true);
        }
        private void frmMainRibbon_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void btnExit_ItemClick(object sender, ItemClickEventArgs e)
        {
            Application.Exit();
        }

        private void btnClose_ItemClick(object sender, ItemClickEventArgs e)
        {

        }

        private void btnCloseAll_ItemClick(object sender, ItemClickEventArgs e)
        {

        }

        private void frmMainRibbon_FormClosing(object sender, FormClosingEventArgs e)
        {
            Properties.Settings.Default.LaskSkin = UserLookAndFeel.Default.SkinName;
            Properties.Settings.Default.Save();
        }
    }
}